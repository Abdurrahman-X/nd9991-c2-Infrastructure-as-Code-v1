### Project Title - Deploy a high-availability web app using CloudFormation
In this project, I have deployed web servers for a highly available web app using CloudFormation. I have written the code that creates and deploys the infrastructure and application for an Instagram-like app from the ground up. I began with deploying the networking components, followed by servers, security roles and software. 


The Load Balancer DNS is: http://udagr-udagr-v8qqy08he2b8-1120162141.us-east-1.elb.amazonaws.com/ 


